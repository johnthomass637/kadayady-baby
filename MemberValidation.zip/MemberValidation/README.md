# Node-Express-MongoDB-Starter

This is a MongoDB Express Boiler Plate Template
